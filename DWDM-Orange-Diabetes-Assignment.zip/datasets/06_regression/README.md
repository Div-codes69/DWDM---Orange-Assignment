# 06 Regression

**Aim:** Predict numeric disease progression.

**Workflow:** File -> Select Columns -> Linear Regression / Random Forest / kNN -> Test and Score.

Set `progression` as the target and ignore `risk`, because it is derived from progression. Compare Linear Regression, Random Forest (10 trees), and kNN (k=5) with 10-fold cross-validation using RMSE, MAE, MSE, and R-squared.
