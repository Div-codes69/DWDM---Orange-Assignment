# Diabetes dataset preparation

`prepare_diabetes_exports.py` loads the 442-row Diabetes dataset from scikit-learn, restores familiar clinical-scale feature values, and creates the derived `risk` class. It also creates one CSV input for each Orange practical.

The ten predictors are age, sex, bmi, bp, tc, ldl, hdl, tch, ltg, and glu. `progression` is used as the regression target in Experiment 6 and retained as metadata for classification-focused experiments.
