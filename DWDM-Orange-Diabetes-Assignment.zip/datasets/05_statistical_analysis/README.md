# 05 Statistical Analysis

**Aim:** Inspect descriptive statistics and class-wise distributions.

**Workflow:** File -> Feature Statistics, Distributions, Box Plot.

Review mean, median, dispersion, minimum, maximum, and missing values. Use Distributions and Box Plot to compare `bmi` and `ltg` for low and high risk groups.
