"""Create reproducible CSV inputs for the nine Orange DWDM practicals."""
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.datasets import load_diabetes

ROOT = Path(__file__).resolve().parent
FEATURES = ["age", "sex", "bmi", "bp", "tc", "ldl", "hdl", "tch", "ltg", "glu"]

def write(frame, folder, name="input.csv"):
    path = ROOT / folder
    path.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path / name, index=False)

data = load_diabetes()
frame = pd.DataFrame(data.data, columns=FEATURES)
# Convert standardized values to readable units for Orange demonstrations.
frame["age"] = np.rint(48.5 + frame["age"] / 0.0476 * 13.0).clip(19, 79)
frame["sex"] = np.where(frame["sex"] > 0, 2, 1)
frame["bmi"] = 26.4 + frame["bmi"] / 0.0476 * 4.0
frame["bp"] = 94.6 + frame["bp"] / 0.0476 * 13.0
for col in ["tc", "ldl", "hdl", "tch", "ltg", "glu"]:
    frame[col] = frame[col].round(3)
frame["progression"] = data.target.astype(int)
frame["risk"] = np.where(frame["progression"] > np.median(frame["progression"]), "high", "low")
frame.to_csv(ROOT / "diabetes.csv", index=False)

dirty = frame.copy()
rng = np.random.default_rng(42)
for col in ["bmi", "bp", "tc", "ltg", "sex"]:
    dirty.loc[rng.choice(dirty.index, size=22, replace=False), col] = np.nan
write(dirty, "01_data_cleaning", "diabetes_missing.csv")
write(frame[["age", "bmi", "bp", "ltg", "progression", "risk"]], "02_data_reduction")
write(frame, "03_data_transformation")
write(frame[["age", "sex", "bmi", "bp", "ltg", "glu", "risk"]], "04_association_rules")
write(frame, "05_statistical_analysis")
write(frame.drop(columns=["risk"]), "06_regression")
write(frame[["age", "bmi", "bp", "tc", "ltg", "glu", "risk"]], "07_outlier_analysis")
write(frame[["age", "bmi", "bp", "tc", "ltg", "glu", "risk"]], "08_kmeans")
write(frame[["age", "bmi", "bp", "tc", "ltg", "glu", "risk"]], "09_simple_kmeans")
print(f"Wrote Diabetes inputs to {ROOT}")
