# 09 Simple K-Means Evaluation

**Aim:** Compare two clusters with the derived risk class.

**Workflow:** File -> Select Columns -> Normalize -> k-Means -> Pivot Table / Data Table.

Use the same six normalized numeric predictors and set k=2 with one random initialization. Use Pivot Table to compare `risk` with the generated Cluster column, and inspect centroid values in Data Table.
