# 07 Outlier Analysis

**Aim:** Identify unusual observations.

**Workflow:** File -> Select Columns -> Outliers -> Scatter Plot / Data Table.

Use the numeric predictors `age`, `bmi`, `bp`, `tc`, `ltg`, and `glu`. Configure the Outliers widget with the covariance estimator and 10% contamination, then inspect flagged cases in a BMI-versus-LTG scatter plot.
