# 08 K-Means Clustering

**Aim:** Group Diabetes observations without using the risk label.

**Workflow:** File -> Select Columns -> Normalize -> k-Means -> Scatter Plot / Data Table.

Normalize the six numeric predictors to [0, 1]. Configure k-Means with 3 clusters, k-means++ initialization, 10 restarts, and a 300-iteration limit. Inspect cluster sizes and silhouette score.
