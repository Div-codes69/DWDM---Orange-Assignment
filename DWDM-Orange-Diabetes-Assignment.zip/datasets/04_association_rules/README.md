# 04 Association Rules with Apriori

**Aim:** Discover frequent itemsets and rules.

**Workflow:** File -> Select Columns -> Discretize -> Association Rules.

Keep `age`, `sex`, `bmi`, `bp`, `ltg`, `glu`, and `risk`. Discretize numerical fields into three equal-frequency intervals. Run Association Rules with minimum support 10% and confidence 80%, then rank results by lift and confidence.
