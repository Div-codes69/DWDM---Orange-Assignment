# 01 Data Cleaning

**Aim:** Handle deliberately introduced missing values with Orange.

**Workflow:** File -> Impute -> Data Table.

Open `diabetes_missing.csv`. Use **Average/Most frequent** in Impute: Orange replaces missing numeric values with the mean and the categorical sex code with its most frequent value. Confirm in Data Table that no missing cells remain.
