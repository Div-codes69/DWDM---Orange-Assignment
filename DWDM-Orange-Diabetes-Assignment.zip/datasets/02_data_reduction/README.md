# 02 Data Reduction

**Aim:** Reduce the feature set while retaining the class.

**Workflow:** File -> Select Columns -> Data Table.

Keep `age`, `bmi`, `bp`, and `ltg` as features. Set `risk` as the target and place `progression` in meta attributes. The resulting data has four predictors plus the class.
