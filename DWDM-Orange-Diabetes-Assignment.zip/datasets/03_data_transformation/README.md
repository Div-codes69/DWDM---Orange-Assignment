# 03 Data Transformation

**Aim:** Put numerical variables on a common scale.

**Workflow:** File -> Normalize -> Data Table.

Use **Normalize to interval [0, 1]**. Compare the input and output tables to verify that numerical attributes have been rescaled while the class label is retained.
