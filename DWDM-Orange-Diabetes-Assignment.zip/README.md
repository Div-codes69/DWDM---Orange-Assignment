# DWDM Orange Assignment - Diabetes Disease Progression

Data Warehousing and Data Mining practicals completed with Orange Data Mining using the scikit-learn Diabetes disease-progression dataset. This repository follows a nine-experiment layout and documents the Orange workflow, settings, and expected observations for each practical.

## Dataset

The Diabetes dataset contains 442 patient records, ten baseline measurements, and a numeric disease-progression score recorded one year later. The included preparation script derives a binary `risk` target: `high` when progression is above the median (140.5), otherwise `low`.

Run the following command to recreate the CSV inputs used in the practicals:

```bash
python datasets/prepare_diabetes_exports.py
```

The script requires `scikit-learn` and writes the shared data file plus experiment-specific CSV inputs beneath `datasets/`.

## Experiments

| # | Practical | Main Orange widgets |
|---|---|---|
| 01 | Data Cleaning | File -> Impute -> Data Table |
| 02 | Data Reduction | File -> Select Columns -> Data Table |
| 03 | Data Transformation | File -> Normalize -> Data Table |
| 04 | Association Rules | File -> Select Columns -> Discretize -> Association Rules |
| 05 | Statistical Analysis | Feature Statistics, Distributions, Box Plot |
| 06 | Regression | Select Columns -> Learners -> Test and Score |
| 07 | Outlier Analysis | Select Columns -> Outliers -> Scatter Plot |
| 08 | K-Means Clustering | Select Columns -> Normalize -> k-Means |
| 09 | Simple K-Means Evaluation | Normalize -> k-Means -> Pivot Table |

## Repository structure

```text
DWDM---Orange-Assignment/
├── README.md
└── datasets/
    ├── prepare_diabetes_exports.py
    ├── README.md
    └── 01_data_cleaning/ ... 09_simple_kmeans/
```

Each numbered folder contains an experiment guide. Add screenshots exported from your own Orange workflows in a `screenshots/` folder when you run the practicals.

## Source

Efron, Hastie, Johnstone and Tibshirani (2004), *Least Angle Regression*. Dataset distributed by scikit-learn as `load_diabetes`.
